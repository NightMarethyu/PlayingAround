import javax.swing.*;

public class Sheep extends Sprite {

  public Sheep(int x, int y) {
    super();
    image = new ImageIcon("Images/sheep.png");
    setLocation(x, y);
  }
}
