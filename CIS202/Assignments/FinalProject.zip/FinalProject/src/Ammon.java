import javax.swing.*;

public class Ammon extends Sprite{

  public Ammon(int x, int y) {
    super();
    image = new ImageIcon( "Images/ammon.png");
    setLocation(x, y);
  }
}
