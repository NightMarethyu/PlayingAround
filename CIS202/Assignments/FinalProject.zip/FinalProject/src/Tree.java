import javax.swing.*;

public class Tree extends Sprite {

  public Tree(int x, int y) {
    super();
    image = new ImageIcon("Images/tree.png");
    setLocation(x, y);
  }
}
