import javax.swing.*;

public class Robber extends Sprite {

  public Robber(int x, int y) {
    super();
    image = new ImageIcon("Images/robber.png");
    setLocation(x, y);
  }
}
