package edu.byuh.cis.cis203.ammon.battleshipwar.sprite;

public interface TickListener {
    void tick();
}
